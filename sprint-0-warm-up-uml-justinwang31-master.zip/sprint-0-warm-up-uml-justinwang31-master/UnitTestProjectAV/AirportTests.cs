﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestFlyingVehicle
{
    [TestClass]
    public class AirportTests
    {
        /// <summary>
        /// Write some airpost tests
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
