﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint_0_Warm_Up
{
    class ToyPlane : Airplane
    {
        bool isWoundUP = false;

        public ToyPlane()
        {
            MaxAltitude = 50;
        }
        public string About()
        {
            string sent1 = "This OOPFlyingVehicle.Airplane has a max altitude of " + MaxAltitude + "ft.\n";
            string sent2 = "It's current altitude is " + CurrentAltitude + " ft.\n";
            string sent3;
            if (isWoundUP == false)
            {
                sent3 = "OOPFlyingVehicleMidterm.Toyplane is not wound up.\n";
            }
            else
            {
                sent3 = "OOPFlyingVehicleMidterm.Toyplane is wound up.\n";
            }

            return sent1 + sent2 + sent3;
        }

        public string getWindUpString()
        {
 
            return isWoundUP.ToString();
        }
        public void Unwind()
        {
            isWoundUP = false;
        }
        public void WindUp()
        {
            isWoundUP = true;
        }

    }
}
