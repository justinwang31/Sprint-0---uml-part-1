﻿using System;

namespace Sprint_0_Warm_Up
{
    public abstract class AerialVehicle
    {
        public int CurrentAltitude { get; set; }

        Engine Engine { get; set; }
        

        public int MaxAltitude { get; set; }
        public AerialVehicle()
        {
            Engine = new Engine();
            MaxAltitude = 41000;
        }

        public string About()
        {
            string sent1 = "This OOPFlyingVehicle.Airplane has a max altitude of "+ MaxAltitude + "ft.\n";
            string sent2 = "It's current altitude is "+ CurrentAltitude +" ft.\n";
            string sent3;
            if(Engine.isStarted == false)
            { 
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is not started.\n";
            }
            else
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is started.\n";
            }
            return sent1 + sent2 + sent3;
        }

        public string TakeOff()
        {
            string sent1;
            
            if(Engine.isStarted == false)
            {
                sent1 = " OOPFlyingVehicleMidterm.Airplane can't fly. it's engine is not started.\n";
            }
            else
            {
                sent1 = " OOPFlyingVehicleMidterm.Airplane can fly. it's engine is started.\n";
            }
            return sent1;

        }

        public void StartEngine()
        {
            Engine.isStarted = true;
        }

        public void FlyDown(int howMuch)
        {
            if (CurrentAltitude - howMuch < 0)
            {
                CurrentAltitude = CurrentAltitude;
            }
            else
            {
                CurrentAltitude = CurrentAltitude - howMuch;
            }
        }

        internal void FlyUp()
        {
            CurrentAltitude = 1000;
        }

        internal void FlyUp(int HowMuch)
        {
            if(HowMuch + CurrentAltitude > MaxAltitude)
            {
                CurrentAltitude = CurrentAltitude;
            }
            else
            {
                CurrentAltitude = HowMuch + CurrentAltitude;
            }
        }
    }
}