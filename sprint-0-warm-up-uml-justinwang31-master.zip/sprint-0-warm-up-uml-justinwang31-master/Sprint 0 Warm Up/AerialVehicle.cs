﻿using System;

namespace Sprint_0_Warm_Up
{
    public abstract class AerialVehicle
    {
        public int CurrentAltitude { get; set; }

        Engine Engine1 { get; set; }
        

        public int MaxAltitude { get; set; }
        public AerialVehicle()
        {
            Engine1 = new Engine();
            MaxAltitude = 41000;
        }

        public string About()
        {
            string sent1 = "This OOPFlyingVehicle.Airplane has a max altitude of "+ MaxAltitude + "ft.\n";
            string sent2 = "It's current altitude is "+ CurrentAltitude +" ft.\n";
            return sent1 + sent2 + Engine1.about();
        }

        public string TakeOff()
        {
            string sent3;
            if (Engine1.isStarted == false)
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is not started.\n";
            }
            else
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is started.\n";
            }
            return sent3;
        }

        public void StartEngine()
        {
            Engine1.isStarted = true;
        }

        public void FlyDown(int howMuch)
        {
            if (CurrentAltitude - howMuch < 0)
            {
                CurrentAltitude = CurrentAltitude;
            }
            else
            {
                CurrentAltitude = CurrentAltitude - howMuch;
            }
        }

        internal void FlyUp()
        {
            CurrentAltitude = 1000;
        }

        internal void FlyUp(int HowMuch)
        {
            if(HowMuch + CurrentAltitude > MaxAltitude)
            {
                CurrentAltitude = CurrentAltitude;
            }
            else
            {
                CurrentAltitude = HowMuch + CurrentAltitude;
            }
        }
    }
}