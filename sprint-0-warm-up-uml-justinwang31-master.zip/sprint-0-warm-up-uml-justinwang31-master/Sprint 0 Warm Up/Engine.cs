﻿namespace Sprint_0_Warm_Up
{
    public class Engine
    {
       public bool isStarted = false;
    }
}