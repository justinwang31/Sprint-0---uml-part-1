﻿namespace Sprint_0_Warm_Up
{
    public class Engine
    {
        public bool isStarted = false;

        public string about()
        {
            string sent3;
            if (isStarted == false)
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is not started.\n";
            }
            else
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is started.\n";
            }
            return sent3;
        }
    }
}