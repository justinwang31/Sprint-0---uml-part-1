﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint_0_Warm_Up
{
    class Airport
    {
        int MaxVehicles;
        List<AerialVehicle> Vehicles = new List<AerialVehicle>();
        public string AirportCode { get; set; }

        Engine Engine1 { get; set; }

        public Airport(string Code)
        {
            Engine1 = new Engine();
        }

        public Airport(string Code, int Maxvehicles)
        {

        }

        public string AllTakeOff()
        {
            string sent1 = "All vehicles take off.";
            return sent1;
        }

        public string Land(AerialVehicle a)
        {
            return a + " has landed.";
        }

        public string Land(List<AerialVehicle> landing)
        {
            for(int i=0; i<landing.Count; i++)
            {
                Console.WriteLine(landing[i] + " has landed"); 
            }
            return landing.Count + " vehicles has landed.";
        }

        public string TakeOff(AerialVehicle a)
        {
            string sent3;
            if (Engine1.isStarted == false)
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is not started.\n";
            }
            else
            {
                sent3 = "OOPFlyingVehicleMidterm.Airplane engine is started.\n";
            }
            return sent3;
        }
    }
  }
